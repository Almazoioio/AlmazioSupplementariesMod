package net.almazoioio.supplementaries.client;

import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class AlmazioChat {
    public List<Text> msg = new ArrayList<Text>();
    public List<OrderedText> orderedMsg = new ArrayList<OrderedText>();
}
