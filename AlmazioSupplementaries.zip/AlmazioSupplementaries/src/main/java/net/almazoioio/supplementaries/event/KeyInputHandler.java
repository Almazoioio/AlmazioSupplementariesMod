package net.almazoioio.supplementaries.event;

import net.almazoioio.supplementaries.AlmazioData;
import net.almazoioio.supplementaries.AlmazioMod;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class KeyInputHandler {
    public static final String KEY_CATEGORY_ALMAZIO = "key.category.almaziosupplementaries.almaziosupplementaries";
    public static final String KEY_ALMAZIO = "key.almaziosupplementaries.almazio";
    public static final String KEY_ERASE = "key.almaziosupplementaries.erase";
    public static KeyBinding almazioKey;
    public static KeyBinding eraseKey;


    public static void registerKeyInputs()
    {
        ClientTickEvents.END_CLIENT_TICK.register(client ->
            {
                if (almazioKey.wasPressed()) {
                    if (AlmazioData.showChat) {
                        AlmazioData.showChat = false;
                        AlmazioMod.LOGGER.info("Chat isn't rendering!");
                    } else {
                        AlmazioData.showChat = true;
                        AlmazioMod.LOGGER.info("Chat is rendering!");
                    }
                }

                if(eraseKey.wasPressed())
                {
                    if(AlmazioData.mode+1 > AlmazioData.modes-1)
                    {
                        AlmazioData.mode = 0;
                        AlmazioData.switchChat();
                    } else
                    {
                        AlmazioData.mode++;
                        AlmazioData.switchChat();
                    }
                }
        });
    }
    public static void register()
    {
        almazioKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                KEY_ALMAZIO,
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F4,
                KEY_CATEGORY_ALMAZIO
        ));
        eraseKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                KEY_ERASE,
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F6,
                KEY_CATEGORY_ALMAZIO
        ));

        registerKeyInputs();

    }

}
