package net.almazoioio.supplementaries.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.almazoioio.supplementaries.AlmazioData;
import net.almazoioio.supplementaries.AlmazioMod;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class AlmazioRenderer implements HudRenderCallback {
    private static final Identifier CHATGUI = new Identifier(AlmazioMod.ID,"textures/gui/chatgui.png");

    @Override
    public void onHudRender(MatrixStack matrix, float tickDelta)
    {
        if(AlmazioData.showChat) {
            int x = 0;
            int y = 0;
            float s1 = 332.0f / 1920.0f;
            float s2 = 1000.0f / 1080.0f;

            if (AlmazioMod.client != null) {
                float height = (float) AlmazioMod.client.getWindow().getScaledHeight();
                y = (int) (height * s2);

                int alpha = 256;

                RenderSystem.setShader(GameRenderer::getPositionTexProgram);
                RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
                RenderSystem.setShaderTexture(0, CHATGUI);
                DrawableHelper.drawTexture(matrix, x, y, 0, 0, 167 * 2, 13 * 2, 167 * 2, 13 * 2);

                for (int i = 0; i < AlmazioData.visibleMsg.size(); i++) {
                    alpha = (int)(((double)(AlmazioData.time.getTimeInMillis() - AlmazioData.timeMsg[AlmazioData.timeMsg.length - i - 1]))/39.0625D);
                    AlmazioMod.client.textRenderer.drawWithShadow(matrix, AlmazioData.visibleMsg.get(AlmazioData.visibleMsg.size() - i - 1), 5.0f, y - 10.0f - 10.0f * i, 0x00FFFFFF + (alpha<<24));
                }
            }
        } else
        {
            return;
        }
    }
}
